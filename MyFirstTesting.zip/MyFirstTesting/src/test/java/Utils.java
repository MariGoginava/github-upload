// Configuration class for Form Automation project

public class Utils {
    final static String BASE_URL = "http://the-internet.herokuapp.com/";
    final static String CHROME_DRIVER_LOCATION = "C:\\Web_Drivers";

}